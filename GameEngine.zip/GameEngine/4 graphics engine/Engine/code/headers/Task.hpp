// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once

namespace engine
{
	class Task
	{
	public:
		/// <summary>
		/// Clase padre para todas las tareas con un m�todo run overrideable
		/// </summary>
		virtual void run() = 0;
	};
}

