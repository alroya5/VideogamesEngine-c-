// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include "Task.hpp"
#include<internal/declarations.hpp>
#include <memory>
#include "MessageListener.hpp"

namespace engine
{
	class Scene; //se declara scene sin definir y se define en el archivo fuente (cpp)
	class RenderTask : public Task, public MessageListener
	{
		/// <summary>
		/// Renderer para los modelos de la escena
		/// </summary>
		std::unique_ptr< glt::Render_Node > renderer;


	public:
		/// <summary>
		/// Constructor de clase que inicializa los objetos para sacarlos por la escena
		/// </summary>
		/// <param name="scene"></param>
		RenderTask(Scene& scene);
		/// <summary>
		/// Se inicia la tarea
		/// </summary>
		void run() override;
		/// <summary>
		/// destructor por defecto
		/// </summary>
		~RenderTask();
		/// <summary>
		/// Funci�n para mover la c�mara como un personaje en primera persona
		/// </summary>
		/// <param name="key"></param>
		void MoveCamera(int key);


	private:
		/// <summary>
		/// referencia a la escena
		/// </summary>
		Scene& scene;
		/// <summary>
		/// funci�n de escucha del sistema de mensajer�a para este escucha
		/// </summary>
		/// <param name="message"></param>
		void handle(const Message& message) override;
		//posici�n inicial de la c�mara
		float playerPosX = 0.f;
		float playerPosY = 0.f;
		float playerPosZ = 5.f;
	};
}

