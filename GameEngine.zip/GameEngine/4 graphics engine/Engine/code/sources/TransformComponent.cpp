#include "TransformComponent.hpp"

engine::TransformComponent::~TransformComponent()
{
}
