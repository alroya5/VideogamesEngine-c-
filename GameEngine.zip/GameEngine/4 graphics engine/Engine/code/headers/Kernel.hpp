// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once

#include "Task.hpp"
#include "Window.hpp"
#include <list>

namespace engine
{
	/// <summary>
	/// Esta clase gestiona que tareas hay que ejecutar y la ejecuci�n de las mismas
	/// </summary>
	class Kernel
	{
		/// <summary>
		/// lista de tareas
		/// </summary>
		std::list<Task* > taskList;
		/// <summary>
		/// booleana que sirve para activar y desactivar el bucle principal
		/// </summary>
		bool exit = false;

	public:
		/// <summary>
		/// a�ade tareas al kernel
		/// </summary>
		/// <param name="task"></param>
		void addTask(Task& task);

		/// <summary>
		/// ejecuci�n de tareas
		/// </summary>
		void run();
		/// <summary>
		/// cambia la booleana exit a true para salir del bucle
		/// </summary>
		void stop();

	};
}

