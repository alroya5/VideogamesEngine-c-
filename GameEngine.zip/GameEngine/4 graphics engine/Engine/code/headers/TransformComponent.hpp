// This is free code released into the public domain.
// Drafted by �lvaro Rodr�guez Yag�e in April 2024.
// alroya5@gmail.com
#pragma once
#include <Component.hpp>
#include <glm/vec3.hpp>


using namespace glm;
/// <summary>
/// This component keeps the x,y,z coordinates of an actor
/// </summary>
namespace engine
{
	class TransformComponent :public Component
	{
	public:
		/// <summary>
		/// posici�n del objeto
		/// </summary>
		vec3 position;
		/// <summary>
		/// rotaci�n del objeto
		/// </summary>
		vec3 rotation;
		/// <summary>
		/// escala del objeto
		/// </summary>
		vec3 scale;

		/// <summary>
		/// destructor por defecto
		/// </summary>
		~TransformComponent() override;



	};

}


