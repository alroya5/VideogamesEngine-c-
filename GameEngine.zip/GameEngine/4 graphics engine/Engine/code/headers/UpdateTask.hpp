// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include "Task.hpp"

namespace engine
{
	class UpdateTask : public Task
	{
	public:
		/// <summary>
		/// se inicia el update
		/// </summary>
		void run() override;
	};
}

