// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include <variant>
#include <string>
#include <map>

namespace engine
{
    class Message
    {
    public:
        /// <summary>
        /// Se pasa la id al constructor por defecto
        /// </summary>
        /// <param name="id"></param>
        Message(const std::string& id) : id(id) {}

        /// <summary>
        /// id del mensaje guardado
        /// </summary>
        std::string id;

    private:
        /// <summary>
        /// mapa con variants de los par�metros del mensaje
        /// </summary>
        std::map<std::string, std::variant<int, bool, std::string>> parameters;
    };
}

