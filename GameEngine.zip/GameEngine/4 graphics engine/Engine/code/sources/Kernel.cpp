// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/04/28

#include <Kernel.hpp>

void engine::Kernel::addTask(Task& task)
{
	taskList.push_back(&task);
}

void engine::Kernel::run()
{
	exit = false;
	do 
	{
		for (auto Task : taskList) Task->run();

	} while (!exit);

}

void engine::Kernel::stop()
{
	exit = true;
}
