
// This is free code released into the public domain.
// Drafted by Ángel in January 2019.
// angel.rodriguez@esne.edu

#include <Cube.hpp>

#include <Model.hpp>
#include <Model_Obj.hpp>
#include <Light.hpp>
#include <Render_Node.hpp>
#include <Sample_Renderer.hpp>
#include <Window.hpp>

using namespace std;
using namespace glt;

namespace engine
{

    Sample_Renderer::Sample_Renderer(Window & given_window)
    {
        window = &given_window;

       
        // Se crea el render node de OpenGL Toolkit:

        renderer.reset (new Render_Node);

        // Se crean los elementos básicos necesarios para dibujar un cubo:

        shared_ptr< Model  > cube  (new Model);
        shared_ptr< Model  > cube2  (new Model);
        shared_ptr< Model  > cube3  (new Model);
        shared_ptr< Model  > cube4  (new Model);
        shared_ptr< Model  > floor  (new Model);
        
        shared_ptr< Camera > camera(new Camera(20.f, 1.f, 50.f, 1.f));
        shared_ptr< Light  > light (new Light);

        // Es necesario añadir las mallas a los modelos antes de añadir los modelos a la escena:

        cube->add (shared_ptr< Drawable >(new Cube),Material::default_material());
        cube2->add (shared_ptr< Drawable >(new Cube), Material::default_material ());
        cube3->add (shared_ptr< Drawable >(new Cube), Material::default_material ());
        cube4->add (shared_ptr< Drawable >(new Cube), Material::default_material ());
        floor->add (shared_ptr< Drawable >(new Cube), Material::default_material ());

        // Se añaden los nodos a la escena:

        renderer->add ("camera", camera);
        renderer->add ("light" , light );
        renderer->add ("cube"  , cube  );
        renderer->add ("cube2"  , cube2  );
        renderer->add ("cube3"  , cube3 );
        renderer->add ("cube4"  , cube4  );
        renderer->add ("floor"  , floor  );
       

        // Se configuran algunas propiedades de transformación:

        renderer->get ("camera")->translate (Vector3( playerPosX,  playerPosY,  playerPosZ));
        renderer->get ("light" )->translate (Vector3(10.f, 10.f, 10.f));
        renderer->get ("cube" )->translate (Vector3(5.f, 0.f, 0.f));
        renderer->get ("cube2" )->translate (Vector3(-20.f, 0.f, 0.f));
        renderer->get ("cube3" )->translate (Vector3(20.f, 0.f, 0.f));
        renderer->get ("cube4" )->translate (Vector3(-30.f, 0.f, 0.f));
        renderer->get ("floor" )->translate (Vector3(0.f, -2.f, 4.f));
        renderer->get("floor")->scale(60.f,1.f,60.f);
        
    }

    Sample_Renderer::~Sample_Renderer()
    {
        // En este caso es necesario definir explícitamente el destructor en el archivo
        // de implementación (CPP) para que el compilador pueda destruir el Render_Node
        // pese a que no hay código explícito.
    }

    void Sample_Renderer::MoveCamera(int key)
    {
        switch (key)
        {
        case Keyboard::KEY_W:
            renderer->get("camera")->translate(Vector3(0, 0, -0.1f));
            break;

        case Keyboard::KEY_S:
            renderer->get("camera")->translate(Vector3(0, 0, 0.1f));
            break;

        case Keyboard::KEY_A:
            renderer->get("camera")->translate(Vector3(-0.1f, 0, 0));
            break;

        case Keyboard::KEY_D:
            renderer->get("camera")->translate(Vector3(0.1f, 0, 0));
            break;
        }
        
       
    }



    void Sample_Renderer::render ()
    {
        // Se ajusta el viewport por si el tamaño de la ventana ha cambiado:

        GLsizei width  = GLsizei(window->get_width  ());
        GLsizei height = GLsizei(window->get_height ());

        renderer->get_active_camera ()->set_aspect_ratio (float(width) / height);

        glViewport (0, 0, width, height);

        // Se renderiza la escena y se intercambian los buffers de la ventana para
        // hacer visible lo que se ha renderizado:

        window->clear ();

        renderer->render ();

        window->swap_buffers ();
    }

}
