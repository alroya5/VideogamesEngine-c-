// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/04/28

#include <Scene.hpp>

engine::Scene::Scene(Window & givenWindow) : window(givenWindow), inputTask(*this,kernel), renderTask(*this)
{
	//se a�aden los escuchas del sistema de mensajer�a
	get_message_dispatcher().add_listener(&renderTask, "WKeyPressed");
	get_message_dispatcher().add_listener(&renderTask, "AKeyPressed");
	get_message_dispatcher().add_listener(&renderTask, "SKeyPressed");
	get_message_dispatcher().add_listener(&renderTask, "DKeyPressed");
	//se a�aden las tareas al kernel
	kernel.addTask(inputTask); 
	kernel.addTask(updateTask);
	kernel.addTask(renderTask);



}

void engine::Scene::Run()
{
	kernel.run(); 
}
