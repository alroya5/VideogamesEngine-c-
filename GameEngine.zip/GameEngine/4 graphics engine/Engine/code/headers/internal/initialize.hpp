
// This is free code released into the public domain.
// Drafted by Ángel in January 2019.
// angel.rodriguez@esne.edu

#pragma once

namespace engine
{

    bool initialize (int subsystem);

}
