// This is free code released into the public domain.
// Drafted by �lvaro Rodr�guez Yag�e in April 2024.
// alroya5@gmail.com
#pragma once

#include "Kernel.hpp"
#include "InputTask.hpp"
#include "UpdateTask.hpp"
#include "RenderTask.hpp"
#include "Window.hpp"
#include "MessageDispatcher.hpp"


namespace engine
{
	class Scene
	{
		/// <summary>
		/// Tarea input principal
		/// </summary>
		InputTask inputTask;
		/// <summary>
		/// Tarea update principal
		/// </summary>
		UpdateTask updateTask;
		/// <summary>
		/// tarea render principal
		/// </summary>
		RenderTask renderTask;
		/// <summary>
		/// Kernel de la escena
		/// </summary>
		Kernel kernel;
		/// <summary>
		/// ventana de la escena
		/// </summary>
		Window window;
		/// <summary>
		/// Maneja los mensajes que se env�an y los escuchas de los mismos
		/// </summary>
		MessageDispatcher messageDispatcher;


	public:
		/// <summary>
		/// constructor para inciar las tareas y los escuchas
		/// </summary>
		Scene(Window& window);
		/// <summary>
		/// inicia el kernel y todas sus tareas
		/// </summary>
		void Run();

		/// <summary>
		/// accede a la ventana de la escena
		/// </summary>
		Window& get_window() { return window; }
		/// <summary>
		/// Accede al sistema de mensajer�a
		/// </summary>
		MessageDispatcher& get_message_dispatcher() { return messageDispatcher; }

	};
}

