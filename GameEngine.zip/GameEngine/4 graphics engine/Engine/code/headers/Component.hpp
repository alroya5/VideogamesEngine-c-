// This is free code released into the public domain.
// Drafted by �lvaro Rodr�guez Yag�e in April 2024.
// alroya5@gmail.com
#pragma once
/// <summary>
/// Actor components
/// </summary>
namespace engine
{
	class Component
	{
	public:
		/// <summary>
		/// destructor por defecto
		/// </summary>
		virtual ~Component() = default;
	};

}


