// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include "Message.hpp"

namespace engine
{
	class MessageListener
	{
	public:
		/// <summary>
		/// los escuchas manejan el mensaje que necesiten
		/// </summary>
		/// <param name="message"></param>
		virtual void handle(const Message& message) = 0;
	};
}

