// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include "MessageListener.hpp"
#include "Message.hpp"
#include <map>
#include <string>
#include <list>



using namespace std;

namespace engine
{
    class MessageDispatcher
    {
        /// <summary>
        /// mapa de escuchas de los mensajes
        /// </summary>
        map<  string, list< MessageListener*> > listeners;

    public:

        /// <summary>
        /// a�ade un MessageListener al mapa de escuchas
        /// </summary>
        /// <param name="listener"></param>
        /// <param name="message_id"></param>
        void add_listener(MessageListener* listener, const string& message_id);
        /// <summary>
        /// Remueve un MessageListener del mapa de escuchas
        /// </summary>
        /// <param name="listener"></param>
        /// <param name="message_id"></param>
        void remove_listener(MessageListener& listener, const string& message_id);

        /// <summary>
        /// se manda un mensaje y se busca alg�n escucha que busque ese mensaje, sino no ocurre nada
        /// </summary>
        /// <param name="message"></param>
        void send(const Message& message);
    };
}
