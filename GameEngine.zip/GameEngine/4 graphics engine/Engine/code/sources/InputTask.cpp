#include "InputTask.hpp"
#include "Scene.hpp"

engine:: InputTask::InputTask(Scene& scene, Kernel& kernel) : scene(scene), kernel(kernel)
{

}

void engine::InputTask::run()
{
    engine::Window::Event event;

    while (scene.get_window().poll(event))
    {
        switch (event.type)
        {
        case Window::Event::CLOSE:
        {
            
            kernel.stop();
            break;
        }

        case Window::Event::KEY_PRESSED:
        {
            if (event.data.keyboard.key_code == Keyboard::KEY_ESCAPE)
            {
                kernel.stop();
            }
            else if (event.data.keyboard.key_code == Keyboard::KEY_W)
            {
            
                Message msg("WKeyPressed"); 
                
                scene.get_message_dispatcher().send(msg);
                
            }
            else if (event.data.keyboard.key_code == Keyboard::KEY_S)
            {
                Message msg("SKeyPressed"); 

                scene.get_message_dispatcher().send(msg); 

              
            }
            else if (event.data.keyboard.key_code == Keyboard::KEY_D)
            {
                Message msg("DKeyPressed"); 

                scene.get_message_dispatcher().send(msg); 

               
            }
            else if (event.data.keyboard.key_code == Keyboard::KEY_A)
            {
                Message msg("AKeyPressed"); 
                 
                scene.get_message_dispatcher().send(msg); 

                
            }

            break;
        }


        }
    }

}
