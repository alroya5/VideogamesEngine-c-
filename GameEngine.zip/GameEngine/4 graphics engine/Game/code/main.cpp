// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03engine::

#include <Window.hpp>

#include <Scene.hpp>

using namespace engine;

int main()
{
    //ventana principal
    Window window("TEST", 1280, 720/*, true*/);
    //se activa la sincronizaci�n vertical
    window.enable_vsync();

    //se crea la escena
    Scene newScene(window);

    //inicia la escena
    newScene.Run();


    return 0;
}

