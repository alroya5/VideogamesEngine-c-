#include "UpdateTask.hpp"

void engine::UpdateTask::run()
{
}
