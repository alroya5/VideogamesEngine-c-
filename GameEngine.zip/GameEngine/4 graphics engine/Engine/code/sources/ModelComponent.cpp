#include "ModelComponent.hpp"

engine::ModelComponent::~ModelComponent()
{
}
