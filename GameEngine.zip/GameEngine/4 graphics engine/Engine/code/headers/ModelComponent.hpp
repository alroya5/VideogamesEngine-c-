// This is free code released into the public domain.
// Drafted by �lvaro Rodr�guez Yag�e in April 2024.
// alroya5@gmail.com
#pragma once
#include <Component.hpp>
#include < memory>
#include <OpenGL.hpp>
#include <Model.hpp>

namespace engine
{
	class ModelComponent :public Component
	{
		/// <summary>
		/// modelo del objeto
		/// </summary>
		std::shared_ptr<glt::Model> model;
	public:
		/// <summary>
		/// destructor por defecto
		/// </summary>
		~ModelComponent() override;
	};
}

