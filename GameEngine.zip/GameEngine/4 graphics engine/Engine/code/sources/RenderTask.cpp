/*
 * RENDERTASK
 * Copyright � 2024+ �lvaro Rodr�guez Yag�e
 *
 * Distributed under the Boost Software License, version  1.0
 * See documents/LICENSE.TXT or www.boost.org/LICENSE_1_0.txt
 *
 * alroya5@gmail.com
 */

#include "RenderTask.hpp"
#include "Scene.hpp"
#include "Entity.hpp"
#include "TransformComponent.hpp"
#include "ModelComponent.hpp"
#include <Render_Node.hpp>
#include <Light.hpp>
#include <Cube.hpp>
#include <Model.hpp>
#include <Model_Obj.hpp>

using namespace std;
using namespace glt;

/// <summary>
/// Constructor de clase que inicializa los objetos para sacarlos por la escena
/// </summary>
/// <param name="scene"></param>
engine::RenderTask::RenderTask(Scene& scene) : scene(scene)
{
    
    renderer.reset(new Render_Node);

    // Se crean los elementos b�sicos necesarios para dibujar un cubo:

    shared_ptr< Model  > cube(new Model);
    shared_ptr< Model  > cube2(new Model);
    shared_ptr< Model  > cube3(new Model);
    shared_ptr< Model  > cube4(new Model);
    shared_ptr< Model  > floor(new Model);
    shared_ptr< Camera > camera(new Camera(20.f, 1.f, 50.f, 1.f));
    shared_ptr< Light  > light(new Light);

    // Es necesario a�adir las mallas a los modelos antes de a�adir los modelos a la escena:

    cube->add(shared_ptr< Drawable >(new Cube), Material::default_material());
    cube2->add(shared_ptr< Drawable >(new Cube), Material::default_material());
    cube3->add(shared_ptr< Drawable >(new Cube), Material::default_material());
    cube4->add(shared_ptr< Drawable >(new Cube), Material::default_material());
    floor->add(shared_ptr< Drawable >(new Cube), Material::default_material());

    // Se a�aden los nodos a la escena:

    renderer->add("camera", camera);
    renderer->add("light", light);
    renderer->add("cube", cube);
    renderer->add("cube2", cube2);
    renderer->add("cube3", cube3);
    renderer->add("cube4", cube4);
    renderer->add("floor", floor);
    

    // Se configuran algunas propiedades de transformaci�n:

    renderer->get("camera")->translate(Vector3(playerPosX, playerPosY, playerPosZ));
    renderer->get("light")->translate(Vector3(10.f, 10.f, 10.f));
    renderer->get("cube")->translate(Vector3(5.f, 0.f, 0.f));
    renderer->get("cube2")->translate(Vector3(-20.f, 0.f, 0.f));
    renderer->get("cube3")->translate(Vector3(20.f, 0.f, 0.f));
    renderer->get("cube4")->translate(Vector3(-30.f, 0.f, 0.f));
    renderer->get("floor")->translate(Vector3(0.f, -2.f, 4.f));
    renderer->get("floor")->scale(60.f, 1.f, 60.f);
}


/// <summary>
/// Se inicia la tarea
/// </summary>
void engine::RenderTask::run()
{
    // Se ajusta el viewport por si el tama�o de la ventana ha cambiado:

    GLsizei width = GLsizei(scene.get_window().get_width());
    GLsizei height = GLsizei(scene.get_window().get_height());

    renderer->get_active_camera()->set_aspect_ratio(float(width) / height);

    glViewport(0, 0, width, height);


    // Se renderiza la escena y se intercambian los buffers de la ventana para
    // hacer visible lo que se ha renderizado:

    scene.get_window().clear(); 

    renderer->render();

    scene.get_window().swap_buffers(); 

}

engine::RenderTask::~RenderTask()
{
    
}

/// <summary>
/// Funci�n para mover la c�mara como un personaje en primera persona
/// </summary>
/// <param name="key"></param>
void engine::RenderTask::MoveCamera(int key)
{
    //Vector3 position = renderer->get("camera")->getPosition();
    switch (key)
    {
    case Keyboard::KEY_W: 
        // Mover hacia adelante
        renderer->get("camera")->translate(Vector3(0.0f, 0.0f, -0.1f));
        break;

    case Keyboard::KEY_S: 
        // Mover hacia atr�s
        renderer->get("camera")->translate(Vector3(0.0f, 0.0f, 0.1f));
        break;

    case Keyboard::KEY_A: 
        // Mover hacia la izquierda
        renderer->get("camera")->translate(Vector3(-0.1f, 0.0f, 0.0f));
        break;

    case Keyboard::KEY_D: 
        // Mover hacia la derecha
        renderer->get("camera")->translate(Vector3(0.1f, 0.0f, 0.0f));
        break;

    default:
        // Tecla no reconocida
        break;



    }
}

/// <summary>
/// funci�n de escucha del sistema de mensajer�a para este escucha
/// </summary>
/// <param name="message"></param>
void engine::RenderTask::handle(const Message& message)
{
    //dependiendo del mensaje enviado se realiza una acci�n u otra
    if (message.id == "WKeyPressed") 
    {
        MoveCamera(Keyboard::KEY_W);
    }
    else if (message.id == "SKeyPressed")
    {
        MoveCamera(Keyboard::KEY_S);
    }
    else if (message.id == "AKeyPressed")
    {
        MoveCamera(Keyboard::KEY_A);
    }
    else if (message.id == "DKeyPressed")
    {
        MoveCamera(Keyboard::KEY_D);
    }

}
