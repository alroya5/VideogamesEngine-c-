// Este c�digo es de dominio p�blico.
// alroya5@gmail.com
// 2024/06/03
#pragma once
#include "Task.hpp"



namespace engine
{
	class Scene;
	class Kernel;

	class InputTask :public Task
	{
	public:
		/// <summary>
		/// referencia a la escena para acceder a los mensajes y dem�s
		/// </summary>
		Scene& scene;
		/// <summary>
		/// referencia al kernel de tareas
		/// </summary>
		Kernel& kernel;
		/// <summary>
		/// Constructor por defecto para a�adir la escena y kernel
		/// </summary>
		/// <param name="scene"></param>
		/// <param name="kernel"></param>
		InputTask(Scene& scene, Kernel& kernel);
		/// <summary>
		/// inicia la tarea
		/// </summary>
		void run() override;

	};
	
}
