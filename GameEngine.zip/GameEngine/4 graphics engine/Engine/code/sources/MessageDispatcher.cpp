#include "MessageDispatcher.hpp"

void engine::MessageDispatcher::add_listener(MessageListener* listener, const string& message_id)
{
	listeners[message_id].push_back(listener); 
}

void engine::MessageDispatcher::remove_listener(MessageListener& listener, const string& message_id)
{
    auto it = listeners.find(message_id);
    if (it != listeners.end()) {
        it->second.remove(&listener);
        if (it->second.empty()) {
            listeners.erase(it);
        }
    }
}

void engine::MessageDispatcher::send(const Message& message)
{
    auto it = listeners.find(message.id);
    if (it != listeners.end()) 
    {
        for (auto& listener : it->second)
        {
            listener->handle(message);
        }
    }
   
}
