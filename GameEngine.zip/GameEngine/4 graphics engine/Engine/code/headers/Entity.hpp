// This is free code released into the public domain.
// Drafted by �lvaro Rodr�guez Yag�e in April 2024.
// alroya5@gmail.com
#pragma once
#include <Component.hpp>
#include <map>
#include <memory>
#include <string>

using namespace std;
/// <summary>
/// Actor with gameobject map
/// </summary>
namespace engine
{
	class Entity
	{
		/// <summary>
		/// mapa de componentes de cada entidad
		/// </summary>
		map<string, shared_ptr< Component>> Components;


	public:
		/// <summary>
		/// Funci�n para a�adir componentes a una entidad
		/// </summary>
		/// <param name="name"></param>
		/// <param name="component"></param>
		void addComponent(string name, shared_ptr<Component> component)
		{
			Components.emplace(name, component);
		}


	};
}

